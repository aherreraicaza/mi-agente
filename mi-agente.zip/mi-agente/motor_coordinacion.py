class MotorCoordinacion:

    def __init__(self, parametros=None):
        self.parametros = parametros or {
            "creatividad": 0.5,
            "precision": 0.5,
            "estructura": 0.5
        }

    # ============================================================
    # 1. ANALIZAR LA PETICIÓN (PROFESIONAL)
    # ============================================================
    def analizar(self, peticion):
        peticion_lower = peticion.lower()

        # ----- Tipos de texto -----
        es_presentacion = "presentación" in peticion_lower or "presentacion" in peticion_lower
        es_guion = "guion" in peticion_lower or "guión" in peticion_lower
        es_resumen = "resumen" in peticion_lower
        es_explicacion = "explica" in peticion_lower or "explicación" in peticion_lower

        es_texto = es_presentacion or es_guion or es_resumen or es_explicacion

        # ----- Proyectos web -----
        es_web = any(x in peticion_lower for x in [
            "web", "html", "css", "js", "sitio", "página", "pagina"
        ])

        # ----- Proyectos especiales -----
        es_clinica = "clínica" in peticion_lower or "dental" in peticion_lower
        es_portafolio = "portafolio" in peticion_lower or "portfolio" in peticion_lower
        es_tienda = "tienda" in peticion_lower or "ecommerce" in peticion_lower

        return {
            "objetivo": peticion,
            "es_texto": es_texto,
            "es_presentacion": es_presentacion,
            "es_guion": es_guion,
            "es_resumen": es_resumen,
            "es_explicacion": es_explicacion,
            "es_web": es_web,
            "es_clinica": es_clinica,
            "es_portafolio": es_portafolio,
            "es_tienda": es_tienda
        }
    # ============================================================
    # 2. DEFINIR ARQUITECTURA (PROFESIONAL)
    # ============================================================
    def diseñar_arquitectura(self, analisis):

        # Si es texto → NO generar proyecto web
        if analisis["es_texto"]:
            return {"archivos": ["presentacion.txt"]}

        # Arquitectura base
        archivos = ["README.md", "config.json"]

        # ----- Proyecto web general -----
        if analisis["es_web"]:
            archivos += ["index.html", "style.css", "script.js"]

        # ----- Proyecto de clínica -----
        if analisis["es_clinica"]:
            archivos.append("clinica.json")

        # ----- Proyecto de portafolio -----
        if analisis["es_portafolio"]:
            archivos.append("portafolio.json")

        # ----- Proyecto de tienda / ecommerce -----
        if analisis["es_tienda"]:
            archivos.append("productos.json")
            archivos.append("carrito.js")

        return {"archivos": archivos}

    # ============================================================
    # 3. GENERAR INSTRUCCIONES PARA EL MODELO (PROFESIONAL)
    # ============================================================
    def generar_instrucciones(self, analisis, arquitectura):

        c = self.parametros["creatividad"]
        p = self.parametros["precision"]
        e = self.parametros["estructura"]

        # ------------------------------------------------------------
        # MODO TEXTO (presentación, guion, resumen, explicación)
        # ------------------------------------------------------------
        if analisis["es_texto"]:
            return f"""
El usuario ha pedido un contenido textual: {analisis['objetivo']}

Debes generar SOLO el archivo presentacion.txt
NO generes HTML, CSS, JS, imágenes ni carpetas.

Formato obligatorio:
ARCHIVO: presentacion.txt
contenido del texto solicitado

Parámetros evolutivos:
- Creatividad: {c:.2f}
- Precisión: {p:.2f}
- Estructura: {e:.2f}

Reglas estrictas:
- Sé claro, estructurado y profesional.
- No inventes archivos.
- No generes carpetas.
- No incluyas comentarios fuera del archivo.
""".strip()

        # ------------------------------------------------------------
        # MODO PROYECTO (HTML, CSS, JS)
        # ------------------------------------------------------------
        lista_archivos = "\n".join(f"- {a}" for a in arquitectura["archivos"])

        return f"""
El usuario ha pedido: {analisis['objetivo']}

Debes generar SOLO los archivos definidos por el motor interno.

Arquitectura obligatoria:
{lista_archivos}

Formato obligatorio por archivo:
ARCHIVO: nombre.ext
contenido del archivo

Parámetros evolutivos:
- Creatividad: {c:.2f}
- Precisión: {p:.2f}
- Estructura: {e:.2f}

Reglas estrictas:
- NO uses frameworks.
- NO generes carpetas.
- Usa SOLO HTML, CSS y JavaScript puro.
- Cada archivo debe estar correctamente cerrado.
- No incluyas comentarios fuera de los bloques de archivo.
- No inventes archivos adicionales.
""".strip()









# ============================================================
# MOTOR DE COORDINACIÓN COMPLETADO
# ============================================================

# Este motor está diseñado para:
# - Analizar peticiones del usuario
# - Definir arquitecturas dinámicas
# - Generar instrucciones profesionales para el modelo
# - Adaptarse a parámetros evolutivos
# - Integrarse con todos los modos del agente principal

# Si en el futuro deseas añadir:
# - Nuevos tipos de proyectos
# - Nuevas arquitecturas
# - Nuevos modos de generación
# - Nuevos parámetros evolutivos

# Solo necesitas ampliar los métodos:
#   analizar()
#   diseñar_arquitectura()
#   generar_instrucciones()

# El resto del sistema ya está preparado para crecer.

