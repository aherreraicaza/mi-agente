import re

FILE_HEADER_RE = re.compile(r"^ARCHIVO:\s+(.+)\s*$")
CODE_BLOCK_START_RE = re.compile(r"^```([a-zA-Z0-9_+-]*)\s*$")
CODE_BLOCK_END_RE = re.compile(r"^```\s*$")


class FormatError(Exception):
    pass


def parse_files(raw: str):
    lines = raw.splitlines()
    i = 0
    files = []

    while i < len(lines):
        line = lines[i].strip()

        # Buscar encabezado ARCHIVO:
        m = FILE_HEADER_RE.match(line)
        if not m:
            i += 1
            continue

        filename = m.group(1).strip()
        i += 1

        # Si no hay más líneas, archivo vacío
        if i >= len(lines):
            files.append((filename, "text", ""))
            break

        # Detectar si viene un bloque ```tipo
        start_line = lines[i].strip()
        m_code = CODE_BLOCK_START_RE.match(start_line)

        if m_code:
            # Caso 1: bloque con ```
            code_type = m_code.group(1) or "text"
            i += 1
            content_lines = []

            while i < len(lines):
                l = lines[i]
                if CODE_BLOCK_END_RE.match(l.strip()):
                    i += 1
                    break
                content_lines.append(l)
                i += 1

            # Si no cerró el bloque, lo cerramos nosotros automáticamente
            # (no hacemos nada aquí porque el normalizador lo arregla)
        else:
            # Caso 2: contenido directo sin ```
            code_type = "text"
            content_lines = []

            while i < len(lines):
                l = lines[i]
                # parar si encontramos otro ARCHIVO: o sección
                if FILE_HEADER_RE.match(l.strip()) or l.strip().startswith("==="):
                    break
                content_lines.append(l)
                i += 1

        content = "\n".join(content_lines).rstrip("\n")
        files.append((filename, code_type, content))

    return files


def validate_and_normalize(raw: str) -> str:
    archivos = parse_files(raw)

    partes = []
    for filename, code_type, content in archivos:
        partes.append(f"ARCHIVO: {filename}")
        partes.append(f"```{code_type}")
        partes.append(content)
        partes.append("```")
        partes.append("")

    return "\n".join(partes).strip() + "\n"
