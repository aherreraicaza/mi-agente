import json
import random
import uuid
import os
import datetime

def crear_logger():
    if not os.path.exists("logs"):
        os.makedirs("logs")

    nombre = datetime.datetime.now().strftime("evolucion_%Y-%m-%d_%H-%M.txt")
    ruta = os.path.join("logs", nombre)

    def log(texto):
        with open(ruta, "a", encoding="utf-8") as f:
            f.write(texto + "\n")

    return log


class AgenteEvolutivo:
    def __init__(self, parametros=None, id=None):
        self.id = id or str(uuid.uuid4())[:8]
        self.parametros = parametros or {
            "creatividad": random.uniform(0.3, 0.9),
            "precision": random.uniform(0.3, 0.9),
            "estructura": random.uniform(0.3, 0.9)
        }
        self.fitness = 0.0

    def evaluar(self, resultado):
        penalizacion = len(resultado["errores"]) * 0.5
        self.fitness = (
            resultado["archivos_generados"] * 0.4 +
            resultado["coherencia"] * 3.0 -
            penalizacion
        )
        return self.fitness

    def mutar(self):
        for k in self.parametros:
            if random.random() < 0.3:
                self.parametros[k] += random.uniform(-0.1, 0.1)
                self.parametros[k] = max(0.0, min(1.0, self.parametros[k]))


class MetaEvolucion:
    ARCHIVO_GUARDADO = "mejores_agentes.json"

    def __init__(self, poblacion_inicial=5):
        self.poblacion = self.cargar_agentes() or [
            AgenteEvolutivo() for _ in range(poblacion_inicial)
        ]

    # ============================================================
    # GUARDAR Y CARGAR AGENTES
    # ============================================================

    def guardar_agentes(self, agentes):
        data = [
            {"id": a.id, "parametros": a.parametros, "fitness": a.fitness}
            for a in agentes
        ]
        with open(self.ARCHIVO_GUARDADO, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
        print("\n💾 Mejores agentes guardados en disco.\n")

    def cargar_agentes(self):
        if not os.path.exists(self.ARCHIVO_GUARDADO):
            return None

        try:
            with open(self.ARCHIVO_GUARDADO, "r", encoding="utf-8") as f:
                data = json.load(f)

            agentes = []
            for item in data:
                agente = AgenteEvolutivo(
                    parametros=item["parametros"],
                    id=item["id"]
                )
                agente.fitness = item.get("fitness", 0)
                agentes.append(agente)

            # print("📂 Agentes evolutivos cargados desde disco.")

            return agentes

        except Exception as e:
            print("⚠ Error cargando agentes guardados:", e)
            return None

    # ============================================================
    # PROCESO EVOLUTIVO
    # ============================================================

    def evolucionar(self, resultados):
        for agente, resultado in zip(self.poblacion, resultados):
            agente.evaluar(resultado)

        self.poblacion.sort(key=lambda a: a.fitness, reverse=True)

        mejores = self.poblacion[:2]

        nuevos = []
        for _ in range(len(self.poblacion) - len(mejores)):
            padre = random.choice(mejores)
            hijo = AgenteEvolutivo(parametros=padre.parametros.copy())
            hijo.mutar()
            nuevos.append(hijo)

        self.poblacion = mejores + nuevos

        # Guardar mejores agentes en disco
        self.guardar_agentes(mejores)

        return mejores
