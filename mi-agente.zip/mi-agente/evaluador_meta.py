import re
from format_validator import validate_and_normalize, FormatError

class EvaluadorMeta:

    def evaluar_respuesta(self, respuesta_raw, arquitectura):
        resultado = {
            "errores": [],
            "archivos_generados": 0,
            "coherencia": 0.0
        }

        # 1. Validación de formato
        try:
            respuesta = validate_and_normalize(respuesta_raw)
        except FormatError as e:
            resultado["errores"].append(str(e))
            return resultado

        # 2. Contar archivos generados
        patron = r"ARCHIVO:\s*(.+?)\n```"
        archivos = re.findall(patron, respuesta)
        resultado["archivos_generados"] = len(archivos)

        # 3. Medir coherencia con la arquitectura esperada
        esperados = set(arquitectura["archivos"])
        generados = set(archivos)

        interseccion = len(esperados.intersection(generados))
        resultado["coherencia"] = interseccion / len(esperados)

        return resultado
