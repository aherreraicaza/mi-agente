# ============================================================
# MEMORIA PERSISTENTE DEL ASISTENTE
# ============================================================

import json
import os

MEMORIA_ARCHIVO = "memoria.json"

def cargar_memoria():
    if not os.path.exists(MEMORIA_ARCHIVO):
        return {}
    try:
        with open(MEMORIA_ARCHIVO, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {}

def guardar_memoria():
    with open(MEMORIA_ARCHIVO, "w", encoding="utf-8") as f:
        json.dump(MEMORIA, f, ensure_ascii=False, indent=4)

# Cargar memoria al iniciar
MEMORIA = cargar_memoria()

def recordar(clave, valor):
    MEMORIA[clave] = valor
    guardar_memoria()

def obtener(clave):
    return MEMORIA.get(clave)


import os
print("📂 Ejecutando desde:", os.getcwd())

import re
import datetime
import json
import requests
import sys

from format_validator import validate_and_normalize, FormatError
from motor_coordinacion import MotorCoordinacion
from meta_evolucion import MetaEvolucion
from evaluador_meta import EvaluadorMeta

# ============================================================
# CONFIGURACIÓN BÁSICA
# ============================================================

CARPETA_PROYECTO = "proyectos_web"
CARPETA_LOGS = "logs"
CONFIG_FILE = "config.txt"
PROMPT_FILE = "prompt.txt"

# ============================================================
# COLORES CONSOLA
# ============================================================

class Color:
    RESET = "\033[0m"
    ROJO = "\033[91m"
    VERDE = "\033[92m"
    AMARILLO = "\033[93m"
    AZUL = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    NEGRITA = "\033[1m"

def c(texto, color):
    return f"{color}{texto}{Color.RESET}"

# ============================================================
# SISTEMA DE LOGS PROFESIONAL
# ============================================================

def crear_logger():
    if not os.path.exists(CARPETA_LOGS):
        os.makedirs(CARPETA_LOGS)

    nombre = datetime.datetime.now().strftime("evolucion_%Y-%m-%d_%H-%M.txt")
    ruta = os.path.join(CARPETA_LOGS, nombre)

    def log(texto):
        with open(ruta, "a", encoding="utf-8") as f:
            f.write(texto + "\n")

    return log

# ============================================================
# CARGA DE CONFIGURACIÓN
# ============================================================

def cargar_api_key():
    if not os.path.exists(CONFIG_FILE):
        raise FileNotFoundError(f"No se encontró {CONFIG_FILE}")
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        linea = f.readline().strip()
        if "=" not in linea:
            raise ValueError("Formato de config.txt inválido. Debe ser: API_KEY=...")
        return linea.split("=", 1)[1].strip()

def cargar_prompt():
    if not os.path.exists(PROMPT_FILE):
        raise FileNotFoundError(f"No se encontró {PROMPT_FILE}")
    with open(PROMPT_FILE, "r", encoding="utf-8") as f:
        return f.read()

try:
    API_KEY = cargar_api_key()
    SYSTEM_PROMPT = cargar_prompt()
except Exception as e:
    print(c(f"⚠ Error cargando configuración: {e}", Color.ROJO))
    API_KEY = ""
    SYSTEM_PROMPT = "Eres un agente que genera proyectos web estructurados."

# ============================================================
# MOTOR DE COORDINACIÓN (CON MEJOR AGENTE EVOLUTIVO SI EXISTE)
# ============================================================

try:
    sistema_temp = MetaEvolucion()
    mejores = sistema_temp.cargar_agentes()

    if mejores:
        print(c("🧠 Usando parámetros del mejor agente evolutivo.\n", Color.CYAN))
        motor = MotorCoordinacion(parametros=mejores[0].parametros)
    else:
        motor = MotorCoordinacion()

except Exception as e:
    print(c(f"⚠ No se pudieron cargar agentes evolutivos: {e}", Color.AMARILLO))
    motor = MotorCoordinacion()

# ============================================================
# FUNCIÓN PARA ENVIAR MENSAJE AL MODELO
# ============================================================

def enviar_mensaje(mensaje_usuario):
    if not API_KEY:
        return {
            "choices": [{
                "message": {
                    "content": "ERROR: No hay API_KEY configurada."
                }
            }]
        }

    url = "https://api.groq.com/openai/v1/chat/completions"

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {API_KEY}"
    }

    data = {
        "model": "llama-3.1-8b-instant",
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": mensaje_usuario}
        ]
    }

    try:
        respuesta = requests.post(url, json=data, headers=headers, timeout=60)
        respuesta.raise_for_status()
        respuesta_json = respuesta.json()

        if "choices" not in respuesta_json:
            return {
                "choices": [{
                    "message": {
                        "content": "ERROR: El modelo no devolvió contenido válido."
                    }
                }]
            }

        return respuesta_json

    except Exception as e:
        return {
            "choices": [{
                "message": {
                    "content": f"ERROR DE CONEXIÓN: {e}"
                }
            }]
        }

# ============================================================
# GENERADOR DE NOMBRES AUTOMÁTICOS
# ============================================================

def generar_nombre_archivo(analisis, peticion):
    texto = peticion.lower()
    texto = re.sub(r"[^a-z0-9áéíóúñ ]", "", texto)
    texto = re.sub(r"\s+", " ", texto).strip()

    palabras = texto.split()
    stopwords = ["hazme", "una", "un", "la", "el", "sobre", "de", "como", "para"]
    palabras = [p for p in palabras if p not in stopwords]

    base = "_".join(palabras[:5]) if palabras else "contenido"

    if analisis.get("es_presentacion"):
        return f"presentacion_{base}.txt"
    if analisis.get("es_guion"):
        return f"guion_{base}.txt"
    if analisis.get("es_resumen"):
        return f"resumen_{base}.txt"
    if analisis.get("es_explicacion"):
        return f"explicacion_{base}.txt"

    return f"texto_{base}.txt"

# ============================================================
# PARSER + GUARDADO DE ARCHIVOS
# ============================================================

def guardar_archivos(respuesta, carpeta=CARPETA_PROYECTO, nombre_personalizado=None):
    try:
        respuesta = validate_and_normalize(respuesta)
    except FormatError as e:
        print(c("\n❌ ERROR DE FORMATO EN LA RESPUESTA DEL MODELO", Color.ROJO))
        print("Motivo:", e)
        print("\nLa respuesta completa fue:\n")
        print(respuesta)
        return

    if not os.path.exists(carpeta):
        os.makedirs(carpeta)

    patron = r"ARCHIVO:\s*(.+?)\n```(.*?)```"
    coincidencias = re.findall(patron, respuesta, flags=re.DOTALL)

    if not coincidencias:
        print(c("⚠ No se detectaron archivos en la respuesta del modelo.", Color.AMARILLO))
        return

    for nombre_archivo, contenido in coincidencias:
        nombre_archivo = nombre_archivo.strip()

        if nombre_personalizado and nombre_archivo.endswith(".txt"):
            nombre_archivo = nombre_personalizado

        if nombre_archivo.endswith(".css"):
            ruta = os.path.join(carpeta, "css", nombre_archivo)
        elif nombre_archivo.endswith(".js"):
            ruta = os.path.join(carpeta, "js", nombre_archivo)
        elif nombre_archivo.lower().endswith((".png", ".jpg", ".jpeg", ".gif", ".webp")):
            ruta = os.path.join(carpeta, "img", nombre_archivo)
        else:
            ruta = os.path.join(carpeta, nombre_archivo)

        os.makedirs(os.path.dirname(ruta), exist_ok=True)

        if os.path.exists(ruta):
            print(c(f"↻ Archivo actualizado: {ruta}", Color.AZUL))
        else:
            print(c(f"✔ Archivo creado: {ruta}", Color.VERDE))

        with open(ruta, "w", encoding="utf-8") as f:
            f.write(contenido.strip())
# ============================================================
# AUDITORÍA
# ============================================================

def auditar_proyecto(carpeta=CARPETA_PROYECTO):
    print(c("\n=== AUDITORÍA DEL PROYECTO INICIADA ===\n", Color.NEGRITA))

    if not os.path.exists(carpeta):
        print(c(f"❌ No existe la carpeta '{carpeta}'.", Color.ROJO))
        return

    archivos = []
    for root, dirs, files in os.walk(carpeta):
        for f in files:
            archivos.append(os.path.join(root, f))

    if not archivos:
        print(c("⚠ No se encontraron archivos en el proyecto.", Color.AMARILLO))
        return

    print(c(f"📁 Archivos detectados ({len(archivos)}):", Color.CYAN))
    for a in archivos:
        print(" -", a)

    print(c("\n🔍 Analizando contenido...\n", Color.NEGRITA))

    informe = []

    for archivo in archivos:
        try:
            with open(archivo, "r", encoding="utf-8") as f:
                contenido = f.read()
        except:
            continue

        analisis = []

        if archivo.endswith(".html"):
            cl = contenido.lower()
            if "<html" not in cl: analisis.append("⚠ Falta etiqueta <html>")
            if "<head" not in cl: analisis.append("⚠ Falta <head>")
            if "<title>" not in cl: analisis.append("⚠ Falta <title>")
            if "<meta" not in cl: analisis.append("⚠ Falta metadata básica")
            if "<h1" not in cl: analisis.append("⚠ No hay encabezado principal (<h1>)")
            if "</body>" not in cl: analisis.append("⚠ Falta cierre </body>")
            if "</html>" not in cl: analisis.append("⚠ Falta cierre </html>")

        if archivo.endswith(".css"):
            if "{" not in contenido or "}" not in contenido:
                analisis.append("⚠ El CSS parece incompleto")
            if "color" not in contenido.lower():
                analisis.append("⚠ No se detectan reglas de color")
            if "font" not in contenido.lower():
                analisis.append("⚠ No se detectan reglas de tipografía")

        if archivo.endswith(".js"):
            if "function" not in contenido and "=>" not in contenido:
                analisis.append("⚠ No se detectan funciones en el JS")
            if "console.log" in contenido:
                analisis.append("ℹ Hay console.log (debug)")
            if "document.querySelector" not in contenido and "addEventListener" not in contenido:
                analisis.append("⚠ No se detecta interacción con el DOM")

        if not analisis:
            analisis.append("✔ Archivo correcto")

        informe.append((archivo, analisis))

    print(c("=== INFORME DE AUDITORÍA ===\n", Color.NEGRITA))
    for archivo, analisis in informe:
        print(c(f"📄 {archivo}:", Color.AZUL))
        for linea in analisis:
            print("   ", linea)
        print()

    print(c("=== AUDITORÍA FINALIZADA ===\n", Color.NEGRITA))


# ============================================================
# REFACTOR
# ============================================================

def refactor_proyecto(carpeta=CARPETA_PROYECTO):
    print(c("\n=== REFACTOR DEL PROYECTO INICIADO ===\n", Color.NEGRITA))

    if not os.path.exists(carpeta):
        print(c(f"❌ No existe la carpeta '{carpeta}'.", Color.ROJO))
        return

    for root, dirs, files in os.walk(carpeta):
        for archivo in files:
            ruta = os.path.join(root, archivo)

            if archivo.endswith((".html", ".css", ".js")):
                with open(ruta, "r", encoding="utf-8") as f:
                    contenido = f.read()

                contenido = contenido.replace("    ", "  ")
                contenido = contenido.replace("\t", "  ")
                contenido = re.sub(r"\n{3,}", "\n\n", contenido)

                with open(ruta, "w", encoding="utf-8") as f:
                    f.write(contenido)

                print(c(f"✔ Refactor aplicado a: {ruta}", Color.VERDE))

    print(c("\n=== REFACTOR FINALIZADO ===\n", Color.NEGRITA))


# ============================================================
# OPTIMIZAR
# ============================================================

def optimizar_proyecto(carpeta=CARPETA_PROYECTO):
    print(c("\n=== OPTIMIZACIÓN DEL PROYECTO INICIADA ===\n", Color.NEGRITA))

    if not os.path.exists(carpeta):
        print(c(f"❌ No existe la carpeta '{carpeta}'.", Color.ROJO))
        return

    for root, dirs, files in os.walk(carpeta):
        for archivo in files:
            ruta = os.path.join(root, archivo)

            if archivo.endswith(".css"):
                with open(ruta, "r", encoding="utf-8") as f:
                    contenido = f.read()

                contenido = re.sub(r"\s+", " ", contenido)
                contenido = contenido.replace(" {", "{").replace("; ", ";")

                with open(ruta, "w", encoding="utf-8") as f:
                    f.write(contenido)

                print(c(f"⚡ CSS optimizado: {ruta}", Color.CYAN))

            if archivo.endswith(".js"):
                with open(ruta, "r", encoding="utf-8") as f:
                    contenido = f.read()

                contenido = re.sub(r"\s+", " ", contenido)

                with open(ruta, "w", encoding="utf-8") as f:
                    f.write(contenido)

                print(c(f"⚡ JS optimizado: {ruta}", Color.CYAN))

    print(c("\n=== OPTIMIZACIÓN FINALIZADA ===\n", Color.NEGRITA))


# ============================================================
# DOCUMENTAR
# ============================================================

def documentar_proyecto(carpeta=CARPETA_PROYECTO):
    print(c("\n=== DOCUMENTACIÓN DEL PROYECTO INICIADA ===\n", Color.NEGRITA))

    if not os.path.exists(carpeta):
        print(c(f"❌ No existe la carpeta '{carpeta}'.", Color.ROJO))
        return

    doc_path = os.path.join(carpeta, "DOCUMENTACION.md")

    contenido = "# 📘 Documentación del Proyecto\n\n"
    contenido += "Este documento describe la estructura y funcionamiento del proyecto.\n\n"

    for root, dirs, files in os.walk(carpeta):
        for archivo in files:
            ruta = os.path.join(root, archivo)
            contenido += f"## Archivo: {archivo}\n"
            contenido += f"Ruta: `{ruta}`\n\n"

            if archivo.endswith(".html"):
                contenido += "- Contiene la estructura principal del sitio.\n"
            if archivo.endswith(".css"):
                contenido += "- Contiene los estilos visuales.\n"
            if archivo.endswith(".js"):
                contenido += "- Contiene la lógica e interactividad.\n"

            contenido += "\n"

    with open(doc_path, "w", encoding="utf-8") as f:
        f.write(contenido)

    print(c(f"📄 Documentación generada en: {doc_path}", Color.VERDE))
    print(c("\n=== DOCUMENTACIÓN FINALIZADA ===\n", Color.NEGRITA))


# ============================================================
# TESTEAR
# ============================================================

def testear_proyecto(carpeta=CARPETA_PROYECTO):
    print(c("\n=== TESTEO DEL PROYECTO INICIADO ===\n", Color.NEGRITA))

    if not os.path.exists(carpeta):
        print(c(f"❌ No existe la carpeta '{carpeta}'.", Color.ROJO))
        return

    tests = []

    for root, dirs, files in os.walk(carpeta):
        for archivo in files:
            if archivo.endswith(".html"):
                tests.append(f"✔ Test HTML: {archivo} existe")
            if archivo.endswith(".css"):
                tests.append(f"✔ Test CSS: {archivo} existe")
            if archivo.endswith(".js"):
                tests.append(f"✔ Test JS: {archivo} existe")

    print(c("=== RESULTADOS DE TESTEO ===\n", Color.NEGRITA))
    for t in tests:
        print(t)

    print(c("\n=== TESTEO FINALIZADO ===\n", Color.NEGRITA))
# ============================================================
# RESPONSIVE
# ============================================================

def responsive_proyecto(carpeta=CARPETA_PROYECTO):
    print(c("\n=== MODO RESPONSIVE INICIADO ===\n", Color.NEGRITA))

    if not os.path.exists(carpeta):
        print(c(f"❌ No existe la carpeta '{carpeta}'.", Color.ROJO))
        return

    # Añadir meta viewport
    for root, dirs, files in os.walk(carpeta):
        for archivo in files:
            if archivo.endswith(".html"):
                ruta = os.path.join(root, archivo)
                with open(ruta, "r", encoding="utf-8") as f:
                    contenido = f.read()

                if '<meta name="viewport"' not in contenido.lower():
                    contenido = contenido.replace(
                        "<head>",
                        "<head>\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">"
                    )
                    print(c(f"✔ Añadido meta viewport en: {ruta}", Color.VERDE))

                with open(ruta, "w", encoding="utf-8") as f:
                    f.write(contenido)

    # CSS responsive
    for root, dirs, files in os.walk(carpeta):
        for archivo in files:
            if archivo.endswith(".css"):
                ruta = os.path.join(root, archivo)
                with open(ruta, "a", encoding="utf-8") as f:
                    f.write("""

/* === RESPONSIVE AUTO === */

img { max-width: 100%; height: auto; }

@media (max-width: 768px) {
  body { padding: 10px; }
  nav ul li { display: block; margin: 10px 0; }
}
""")
                print(c(f"✔ CSS responsive añadido en: {ruta}", Color.VERDE))

    print(c("\n=== MODO RESPONSIVE FINALIZADO ===\n", Color.NEGRITA))


# ============================================================
# SEO
# ============================================================

def seo_proyecto(carpeta=CARPETA_PROYECTO):
    print(c("\n=== MODO SEO INICIADO ===\n", Color.NEGRITA))

    if not os.path.exists(carpeta):
        print(c("❌ No existe la carpeta.", Color.ROJO))
        return

    for root, dirs, files in os.walk(carpeta):
        for archivo in files:
            if archivo.endswith(".html"):
                ruta = os.path.join(root, archivo)
                with open(ruta, "r", encoding="utf-8") as f:
                    contenido = f.read()

                lower = contenido.lower()

                if "<title>" not in lower:
                    contenido = contenido.replace(
                        "<head>",
                        "<head>\n  <title>Web generada por agente inteligente</title>"
                    )

                if "meta name=\"description\"" not in lower:
                    contenido = contenido.replace(
                        "<head>",
                        "<head>\n  <meta name=\"description\" content=\"Sitio web optimizado automáticamente.\">"
                    )

                if "<h1" not in lower:
                    contenido = contenido.replace(
                        "<body>",
                        "<body>\n  <h1>Bienvenido a nuestro sitio web</h1>"
                    )

                with open(ruta, "w", encoding="utf-8") as f:
                    f.write(contenido)

                print(c(f"✔ SEO aplicado en: {ruta}", Color.VERDE))

    print(c("\n=== MODO SEO FINALIZADO ===\n", Color.NEGRITA))


# ============================================================
# ACCESIBILIDAD (A11Y)
# ============================================================

def accesibilidad_proyecto(carpeta=CARPETA_PROYECTO):
    print(c("\n=== MODO A11Y INICIADO ===\n", Color.NEGRITA))

    if not os.path.exists(carpeta):
        print(c("❌ No existe la carpeta.", Color.ROJO))
        return

    for root, dirs, files in os.walk(carpeta):
        for archivo in files:
            if archivo.endswith(".html"):
                ruta = os.path.join(root, archivo)
                with open(ruta, "r", encoding="utf-8") as f:
                    contenido = f.read()

                lower = contenido.lower()

                # lang
                if "<html" in lower and "lang=" not in lower:
                    contenido = contenido.replace("<html", "<html lang=\"es\"")

                # alt en imágenes
                def add_alt(m):
                    tag = m.group(0)
                    if "alt=" not in tag.lower():
                        return tag[:-1] + ' alt="Imagen descriptiva">'
                    return tag

                contenido = re.sub(r"<img[^>]*>", add_alt, contenido, flags=re.IGNORECASE)

                # role nav
                if "<nav" in lower and "role=" not in lower:
                    contenido = contenido.replace("<nav", "<nav role=\"navigation\"")

                with open(ruta, "w", encoding="utf-8") as f:
                    f.write(contenido)

                print(c(f"✔ A11Y aplicado en: {ruta}", Color.VERDE))

    print(c("\n=== MODO A11Y FINALIZADO ===\n", Color.NEGRITA))


# ============================================================
# PERFORMANCE
# ============================================================

def performance_proyecto(carpeta=CARPETA_PROYECTO):
    print(c("\n=== PERFORMANCE PRO INICIADO ===\n", Color.NEGRITA))

    if not os.path.exists(carpeta):
        print(c("❌ No existe la carpeta.", Color.ROJO))
        return

    for root, dirs, files in os.walk(carpeta):
        for archivo in files:
            if archivo.endswith(".html"):
                ruta = os.path.join(root, archivo)
                with open(ruta, "r", encoding="utf-8") as f:
                    contenido = f.read()

                # lazy loading
                def add_lazy(m):
                    tag = m.group(0)
                    if "loading=" not in tag.lower():
                        return tag[:-1] + ' loading="lazy">'
                    return tag

                contenido = re.sub(r"<img[^>]*>", add_lazy, contenido, flags=re.IGNORECASE)

                # defer scripts
                def add_defer(m):
                    tag = m.group(0)
                    if "defer" not in tag.lower():
                        return tag[:-1] + " defer>"
                    return tag

                contenido = re.sub(r"<script[^>]*src=[^>]*>", add_defer, contenido, flags=re.IGNORECASE)

                with open(ruta, "w", encoding="utf-8") as f:
                    f.write(contenido)

                print(c(f"✔ Performance aplicado en: {ruta}", Color.VERDE))

    print(c("\n=== PERFORMANCE PRO FINALIZADO ===\n", Color.NEGRITA))


# ============================================================
# TEMA DARK/LIGHT
# ============================================================

def tema_proyecto(carpeta=CARPETA_PROYECTO):
    print(c("\n=== TEMA DARK/LIGHT INICIADO ===\n", Color.NEGRITA))

    for root, dirs, files in os.walk(carpeta):
        for archivo in files:
            if archivo.endswith(".css"):
                ruta = os.path.join(root, archivo)
                with open(ruta, "a", encoding="utf-8") as f:
                    f.write("""

/* === TEMA AUTO === */

:root {
  --bg: #ffffff;
  --text: #111111;
}

@media (prefers-color-scheme: dark) {
  :root {
    --bg: #000000;
    --text: #ffffff;
  }
}

body {
  background: var(--bg);
  color: var(--text);
}
""")
                print(c(f"✔ Tema añadido en: {ruta}", Color.VERDE))

    print(c("\n=== TEMA FINALIZADO ===\n", Color.NEGRITA))


# ============================================================
# SEGURIDAD
# ============================================================

def seguridad_proyecto(carpeta=CARPETA_PROYECTO):
    print(c("\n=== SEGURIDAD INICIADA ===\n", Color.NEGRITA))

    for root, dirs, files in os.walk(carpeta):
        for archivo in files:
            if archivo.endswith(".html"):
                ruta = os.path.join(root, archivo)
                with open(ruta, "r", encoding="utf-8") as f:
                    contenido = f.read()

                if "content-security-policy" not in contenido.lower():
                    contenido = contenido.replace(
                        "<head>",
                        "<head>\n  <!-- CSP sugerida: default-src 'self'; -->"
                    )

                if "nosniff" not in contenido.lower():
                    contenido = contenido.replace(
                        "<head>",
                        "<head>\n  <!-- X-Content-Type-Options: nosniff -->"
                    )

                with open(ruta, "w", encoding="utf-8") as f:
                    f.write(contenido)

                print(c(f"✔ Seguridad sugerida en: {ruta}", Color.VERDE))

    print(c("\n=== SEGURIDAD FINALIZADA ===\n", Color.NEGRITA))


# ============================================================
# I18N
# ============================================================

def i18n_proyecto(carpeta=CARPETA_PROYECTO):
    print(c("\n=== I18N INICIADO ===\n", Color.NEGRITA))

    i18n_path = os.path.join(carpeta, "i18n")
    os.makedirs(i18n_path, exist_ok=True)

    es = {"titulo": "Bienvenido", "boton": "Más información"}
    en = {"titulo": "Welcome", "boton": "Learn more"}

    with open(os.path.join(i18n_path, "es.json"), "w", encoding="utf-8") as f:
        json.dump(es, f, ensure_ascii=False, indent=2)

    with open(os.path.join(i18n_path, "en.json"), "w", encoding="utf-8") as f:
        json.dump(en, f, ensure_ascii=False, indent=2)

    print(c("✔ Archivos i18n generados", Color.VERDE))
    print(c("\n=== I18N FINALIZADO ===\n", Color.NEGRITA))


# ============================================================
# ANALÍTICA
# ============================================================

def analitica_proyecto(carpeta=CARPETA_PROYECTO):
    print(c("\n=== ANALÍTICA INICIADA ===\n", Color.NEGRITA))

    snippet = """
  <!-- ANALÍTICA (ejemplo) -->
  <!-- <script async src="https://www.googletagmanager.com/gtag/js?id=TU_ID"></script> -->
"""

    for root, dirs, files in os.walk(carpeta):
        for archivo in files:
            if archivo.endswith(".html"):
                ruta = os.path.join(root, archivo)
                with open(ruta, "r", encoding="utf-8") as f:
                    contenido = f.read()

                if "</head>" in contenido:
                    contenido = contenido.replace("</head>", snippet + "\n</head>")

                with open(ruta, "w", encoding="utf-8") as f:
                    f.write(contenido)

                print(c(f"✔ Analítica añadida en: {ruta}", Color.VERDE))

    print(c("\n=== ANALÍTICA FINALIZADA ===\n", Color.NEGRITA))


# ============================================================
# MODO MEJORAR — EJECUTA TODAS LAS MEJORAS AUTOMÁTICAMENTE
# ============================================================

def mejorar_proyecto(carpeta=CARPETA_PROYECTO):
    print(c("\n=== MODO MEJORAR (FULL AUTO) INICIADO ===\n", Color.NEGRITA))

    if not os.path.exists(carpeta):
        print(c(f"❌ No existe la carpeta '{carpeta}'.", Color.ROJO))
        return

    print(c("➡ Aplicando responsive...", Color.CYAN))
    responsive_proyecto(carpeta)

    print(c("➡ Aplicando SEO...", Color.CYAN))
    seo_proyecto(carpeta)

    print(c("➡ Aplicando accesibilidad (A11Y)...", Color.CYAN))
    accesibilidad_proyecto(carpeta)

    print(c("➡ Aplicando performance PRO...", Color.CYAN))
    performance_proyecto(carpeta)

    print(c("➡ Aplicando tema dark/light...", Color.CYAN))
    tema_proyecto(carpeta)

    print(c("➡ Aplicando seguridad...", Color.CYAN))
    seguridad_proyecto(carpeta)

    print(c("➡ Creando estructura multi-idioma (i18n)...", Color.CYAN))
    i18n_proyecto(carpeta)

    print(c("➡ Añadiendo estructura de analítica...", Color.CYAN))
    analitica_proyecto(carpeta)

    print(c("➡ Auditoría final...", Color.CYAN))
    auditar_proyecto(carpeta)

    print(c("\n=== MODO MEJORAR (FULL AUTO) FINALIZADO ===\n", Color.NEGRITA))
# ============================================================
# SISTEMA DE AYUDA
# ============================================================

def mostrar_ayuda():
    print(c("\n=== AYUDA DEL AGENTE ===\n", Color.NEGRITA))
    print("Comandos disponibles:\n")
    print("  generar <texto>        → Genera un proyecto web")
    print("  responsive             → Aplica responsive")
    print("  seo                    → Aplica SEO")
    print("  accesibilidad          → Aplica accesibilidad A11Y")
    print("  performance            → Optimiza rendimiento")
    print("  tema                   → Añade tema dark/light")
    print("  seguridad              → Añade cabeceras de seguridad")
    print("  i18n                   → Crea estructura multi-idioma")
    print("  analitica              → Añade snippet de analítica")
    print("  auditar                → Auditoría completa")
    print("  refactor               → Limpieza de código")
    print("  optimizar              → Minificación CSS/JS")
    print("  documentar             → Genera DOCUMENTACION.md")
    print("  testear                → Tests básicos")
    print("  mejorar                → Ejecuta TODAS las mejoras")
    print("  salir                  → Cierra el agente\n")
    print("Alias rápidos:")
    print("  r = responsive, s = seo, a11y = accesibilidad, p = performance")
    print("  m = mejorar, x = salir\n")
    print(c("========================================\n", Color.NEGRITA))

# ============================================================
# SISTEMA DE PLUGINS
# ============================================================

PLUGINS_DIR = "plugins"

def cargar_plugins():
    if not os.path.exists(PLUGINS_DIR):
        os.makedirs(PLUGINS_DIR)
        return {}

    plugins = {}
    for archivo in os.listdir(PLUGINS_DIR):
        if archivo.endswith(".py"):
            nombre = archivo[:-3]
            try:
                mod = __import__(f"{PLUGINS_DIR}.{nombre}", fromlist=[nombre])
                if hasattr(mod, "run"):
                    plugins[nombre] = mod.run
                    print(c(f"🔌 Plugin cargado: {nombre}", Color.CYAN))
            except Exception as e:
                print(c(f"⚠ Error cargando plugin {nombre}: {e}", Color.ROJO))

    return plugins

PLUGINS = cargar_plugins()

def crear_proyecto(nombre):
    ruta = f"proyectos_web/{nombre}"

    if not os.path.exists(ruta):
        os.makedirs(ruta)
        os.makedirs(f"{ruta}/assets", exist_ok=True)

        with open(f"{ruta}/index.html", "w", encoding="utf-8") as f:
            f.write(f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{nombre}</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Proyecto {nombre}</h1>
    <script src="script.js"></script>
</body>
</html>""")

        with open(f"{ruta}/style.css", "w", encoding="utf-8") as f:
            f.write("/* Estilos base */\nbody { font-family: Arial; }")

        with open(f"{ruta}/script.js", "w", encoding="utf-8") as f:
            f.write("// JS base\nconsole.log('Proyecto creado');")

        print(c(f"✔ Proyecto '{nombre}' creado en {ruta}", Color.VERDE))
    else:
        print(c(f"⚠ El proyecto '{nombre}' ya existe.", Color.AMARILLO))

# ============================================================
# EJECUTOR DE COMANDOS
# ============================================================

def ejecutar_comando(cmd, argumento=None):
    cmd = cmd.lower().strip()

    # Alias
    alias = {
        "r": "responsive",
        "s": "seo",
        "a11y": "accesibilidad",
        "p": "performance",
        "m": "mejorar",
        "x": "salir"
    }
    if cmd in alias:
        cmd = alias[cmd]

    # Router
    if cmd == "responsive":
        responsive_proyecto()
    elif cmd == "seo":
        seo_proyecto()
    elif cmd == "accesibilidad":
        accesibilidad_proyecto()
    elif cmd == "performance":
        performance_proyecto()
    elif cmd == "tema":
        tema_proyecto()
    elif cmd == "seguridad":
        seguridad_proyecto()
    elif cmd == "i18n":
        i18n_proyecto()
    elif cmd == "analitica":
        analitica_proyecto()
    elif cmd == "auditar":
        auditar_proyecto()
    elif cmd == "refactor":
        refactor_proyecto()
    elif cmd == "optimizar":
        optimizar_proyecto()
    elif cmd == "documentar":
        documentar_proyecto()
    elif cmd == "testear":
        testear_proyecto()
    elif cmd == "mejorar":
        mejorar_proyecto()

    # ⭐ LISTAR PLUGINS
    elif cmd == "dev:plugins":
        print(c("\n=== PLUGINS DISPONIBLES ===", Color.NEGRITA))
        for p in PLUGINS:
            print(" -", p)
        print()

    # ⭐ EJECUTAR PLUGIN
    elif cmd == "plugin":
        if not argumento:
            print(c("❌ Debes escribir: plugin <nombre> [parametro]", Color.ROJO))
            return

        partes = argumento.split()
        nombre_plugin = partes[0]
        parametro = partes[1] if len(partes) > 1 else None

        if nombre_plugin not in PLUGINS:
            print(c(f"❌ Plugin '{nombre_plugin}' no encontrado.", Color.ROJO))
            print(c("ℹ Usa 'dev:plugins' para ver los plugins cargados.", Color.AMARILLO))
            return

        try:
            if parametro:
                resultado = PLUGINS[nombre_plugin](parametro)
            else:
                resultado = PLUGINS[nombre_plugin]()

            print(c(f"✔ Plugin ejecutado: {nombre_plugin}", Color.VERDE))
            print(resultado)

        except Exception as e:
            print(c(f"❌ Error ejecutando el plugin '{nombre_plugin}': {e}", Color.ROJO))

    # ⭐ CREAR PROYECTO
    elif cmd == "crear":
        if not argumento:
            print(c("❌ Debes escribir: crear proyecto <nombre>", Color.ROJO))
            return

        partes = argumento.split()
        if len(partes) < 2 or partes[0] != "proyecto":
            print(c("❌ Uso correcto: crear proyecto <nombre>", Color.ROJO))
            return

        nombre = partes[1]
        crear_proyecto(nombre)

    # ⭐ GENERAR
    elif cmd == "generar":
        if not argumento:
            print(c("❌ Debes escribir: generar <texto>", Color.ROJO))
            return
        generar_proyecto(argumento)

    # ⭐ SALIR
    elif cmd == "salir":
        print(c("\n👋 Saliendo del agente...\n", Color.CYAN))
        sys.exit(0)

    # ⭐ COMANDO DESCONOCIDO
    else:
        print(c("❌ Comando no reconocido. Escribe 'ayuda'.", Color.ROJO))




# ============================================================
# GENERAR PROYECTO (INTEGRADO CON MOTOR)
# ============================================================

def generar_proyecto(peticion):
    print(c("\n=== GENERACIÓN DE PROYECTO INICIADA ===\n", Color.NEGRITA))

    analisis = motor.analizar(peticion)
    arquitectura = motor.diseñar_arquitectura(analisis)
    instrucciones = motor.generar_instrucciones(analisis, arquitectura)

    respuesta = enviar_mensaje(instrucciones)
    contenido = respuesta["choices"][0]["message"]["content"]

    nombre = generar_nombre_archivo(analisis, peticion)
    guardar_archivos(contenido, carpeta=CARPETA_PROYECTO, nombre_personalizado=nombre)

    print(c("\n=== GENERACIÓN FINALIZADA ===\n", Color.NEGRITA))


# ============================================================
# DETECCIÓN AUTOMÁTICA DE PETICIONES
# ============================================================

def es_peticion_generar(texto):
    texto = texto.lower()
    patrones = [
        "hazme", "crea", "genera", "quiero una web",
        "necesito una web", "web para", "sitio para"
    ]
    return any(p in texto for p in patrones)


# ============================================================
# MODO INTERACTIVO
# ============================================================

def modo_interactivo():
    print(c("\n=== AGENTE INTELIGENTE INICIADO ===", Color.NEGRITA))
    print(c("Escribe 'ayuda' para ver comandos.\n", Color.CYAN))

    while True:
        entrada = input(c("> ", Color.AZUL)).strip()

        if not entrada:
            continue

        # 1. Si es una petición de generar proyecto, lo hacemos
        if es_peticion_generar(entrada):
            generar_proyecto(entrada)
            continue

        # 2. Detectamos si realmente es un comando
        partes = entrada.split(" ", 1)
        cmd = partes[0]
        arg = partes[1] if len(partes) > 1 else None

        comandos_validos = ["ayuda", "crear", "generar", "abrir", "leer", "plugin"]

        if cmd in comandos_validos:
            ejecutar_comando(cmd, arg)
        else:
            # 3. Si NO es un comando, entramos en modo asistente
            modo_asistente(entrada)

def modo_asistente(texto):
    print(c("\n🤖 Asistente:", Color.VERDE))
    respuesta = generar_respuesta(texto)
    print(respuesta)

# Personalidad del asistente
PERSONALIDAD = (
    "Habla con claridad, seguridad y cercanía. "
    "Eres un asistente que guía, propone, explica y ayuda a avanzar. "
    "No usas tecnicismos innecesarios. "
    "Eres directo, práctico y motivador."
)

# Personalidad del asistente
PERSONALIDAD = (
    "Habla con claridad, seguridad y cercanía. "
    "Eres un asistente que guía, propone, explica y ayuda a avanzar. "
    "No usas tecnicismos innecesarios. "
    "Eres directo, práctico y motivador."
)

# Personalidad del asistente
PERSONALIDAD = (
    "Habla como un colega buena onda: cercano, simpático y relajado. "
    "Eres claro, directo y siempre con actitud positiva. "
    "No eres excesivamente formal, pero sigues siendo útil y respetuoso."
)

def generar_respuesta(texto):
    t = texto.lower().strip()

    # ============================================================
    # MEMORIA AUTOMÁTICA (MEJORADA)
    # ============================================================

    # Guardar nombre
    if "mi nombre es" in t:
        nombre = texto.split("mi nombre es", 1)[1].strip()
        recordar("nombre", nombre)
        return f"Encantado, {nombre}. Lo recordaré."

    # Guardar gustos
    if "me gusta" in t:
        gusto = texto.split("me gusta", 1)[1].strip()
        recordar("gusto", gusto)
        return f"Perfecto, tendré en cuenta que te gusta {gusto}."

    # Detectar proyectos en MUCHAS formas naturales
    disparadores_proyecto = [
        "estoy trabajando en",
        "mi proyecto es",
        "quiero crear",
        "estoy creando",
        "quiero desarrollar",
        "voy a hacer",
        "estoy construyendo",
        "quiero lanzar",
        "quiero montar",
        "estoy diseñando",
        "estoy preparando",
        "quiero empezar",
        "quiero iniciar"
    ]

    for d in disparadores_proyecto:
        if d in t:
            proyecto = texto.split(d, 1)[1].strip()
            recordar("proyecto", proyecto)
            return f"Genial, estaré atento a tu proyecto: {proyecto}."

    # ============================================================
    # RESPUESTAS PERSONALIZADAS SEGÚN MEMORIA
    # ============================================================

    # Saludo más natural y amigable
    saludo = ""
    nombre = obtener("nombre")

    if nombre:
        opciones_saludo = [
            f"{nombre}, genial.",
            f"{nombre}, perfecto.",
            f"{nombre}, te escucho.",
            f"{nombre}, vale.",
            f"{nombre}, entendido.",
            f"{nombre}, sin problema.",
            f"{nombre}, aquí estoy."
        ]
        import random
        saludo = random.choice(opciones_saludo) + " "


# ============================================================
# FUNCIONES AVANZADAS DEL ASISTENTE
# ============================================================

def explicar_proceso_avanzado(texto):
    return (
        "Vamos paso a paso:\n\n"
        "1) Define claramente qué quieres lograr.\n"
        "2) Identifica los recursos que necesitas.\n"
        "3) Divide el objetivo en tareas pequeñas.\n"
        "4) Ejecuta la primera tarea sin esperar a tener todo perfecto.\n"
        "5) Ajusta sobre la marcha.\n\n"
        "Si quieres, puedo adaptar este proceso a tu caso concreto."
    )


def generar_ideas_avanzado(texto):
    return (
        "Aquí tienes ideas que encajan con lo que pides:\n\n"
        "- Idea A: Crear una guía práctica basada en tu experiencia.\n"
        "- Idea B: Automatizar una tarea repetitiva con un script.\n"
        "- Idea C: Diseñar un pequeño servicio digital útil.\n"
        "- Idea D: Crear contenido educativo.\n"
        "- Idea E: Construir una herramienta simple que resuelva un problema.\n\n"
        "Si quieres, puedo desarrollar cualquiera de ellas."
    )


def resumir_texto_avanzado(texto):
    return (
        "Aquí tienes un resumen claro y directo:\n\n"
        "- El mensaje trata sobre simplificar información.\n"
        "- El objetivo es obtener una versión más corta y útil.\n"
        "- La idea principal se mantiene, pero sin detalles innecesarios."
    )


def explicar_concepto_avanzado(texto):
    return (
        "Este concepto se basa en entender la idea principal, "
        "simplificarla y aplicarla de forma práctica.\n\n"
        "Si quieres, puedo darte ejemplos reales."
    )


def analizar_texto_avanzado(texto):
    return (
        "Aquí tienes un análisis rápido:\n\n"
        "- Identifica la intención del mensaje.\n"
        "- Observa las palabras clave.\n"
        "- Determina el objetivo final.\n"
        "- Evalúa si hay dudas, ideas o peticiones.\n\n"
        "Puedo hacer un análisis más profundo si me das más contexto."
    )


def transformar_texto_avanzado(texto):
    return (
        "Aquí tienes una versión mejorada del mensaje:\n\n"
        f"«{texto.capitalize()}, presentado de forma más clara y directa.»\n\n"
        "Si quieres, puedo reescribirlo en otro estilo."
    )

# ============================================================
# MODO POR ARGUMENTOS
# ============================================================

def modo_argumentos():
    args = sys.argv[1:]

    if not args:
        modo_interactivo()
        return

    if es_peticion_generar(" ".join(args)):
        generar_proyecto(" ".join(args))
        return

    cmd = args[0]
    arg = " ".join(args[1:]) if len(args) > 1 else None

    if cmd == "ayuda":
        mostrar_ayuda()
    else:
        ejecutar_comando(cmd, arg)


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":
    modo_argumentos()
# ============================================================
# BANNER PROFESIONAL
# ============================================================

def mostrar_banner():
    print(c("""
============================================================
        AGENTE INTELIGENTE DE GENERACIÓN WEB v3.0
============================================================
    """, Color.MAGENTA))


# ============================================================
# AUTOCOMPLETADO (si el sistema lo soporta)
# ============================================================

try:
    import readline

    comandos = [
        "generar", "responsive", "seo", "accesibilidad", "performance",
        "tema", "seguridad", "i18n", "analitica", "auditar",
        "refactor", "optimizar", "documentar", "testear", "mejorar",
        "ayuda", "salir"
    ]

    def completer(text, state):
        opciones = [c for c in comandos if c.startswith(text)]
        if state < len(opciones):
            return opciones[state]
        return None

    readline.set_completer(completer)
    readline.parse_and_bind("tab: complete")

except Exception:
    pass  # No pasa nada si el sistema no soporta autocompletado



# ============================================================
# MODO VERBOSE / SILENCIOSO
# ============================================================

VERBOSE = True

def log_verbose(msg):
    if VERBOSE:
        print(c(msg, Color.AMARILLO))


# ============================================================
# COMANDOS OCULTOS PARA DESARROLLADOR
# ============================================================

def comando_dev(cmd):
    if cmd == "dev:plugins":
        print(c("\n=== PLUGINS DISPONIBLES ===", Color.NEGRITA))
        for p in PLUGINS:
            print(" -", p)
        print()
        return True

    if cmd == "dev:reload":
        print(c("♻ Recargando plugins...", Color.CYAN))
        cargar_plugins()
        return True

    return False


# ============================================================
# LIMPIAR PROYECTO
# ============================================================

def limpiar_proyecto(carpeta=CARPETA_PROYECTO):
    if not os.path.exists(carpeta):
        print(c("⚠ No hay proyecto para limpiar.", Color.AMARILLO))
        return

    for root, dirs, files in os.walk(carpeta, topdown=False):
        for f in files:
            os.remove(os.path.join(root, f))
        for d in dirs:
            os.rmdir(os.path.join(root, d))

    print(c("🧹 Proyecto limpiado completamente.", Color.VERDE))


# ============================================================
# EXPORTAR LOGS
# ============================================================

def exportar_logs(destino="logs_exportados.txt"):
    if not os.path.exists(CARPETA_LOGS):
        print(c("⚠ No hay logs para exportar.", Color.AMARILLO))
        return

    with open(destino, "w", encoding="utf-8") as out:
        for archivo in os.listdir(CARPETA_LOGS):
            ruta = os.path.join(CARPETA_LOGS, archivo)
            with open(ruta, "r", encoding="utf-8") as f:
                out.write(f"\n=== {archivo} ===\n")
                out.write(f.read())

    print(c(f"📤 Logs exportados a {destino}", Color.VERDE))


# ============================================================
# VALIDAR ESTRUCTURA DEL PROYECTO
# ============================================================

def validar_estructura(carpeta=CARPETA_PROYECTO):
    print(c("\n=== VALIDACIÓN DE ESTRUCTURA ===\n", Color.NEGRITA))

    esperado = ["index.html", "css", "js", "img"]
    faltantes = []

    for item in esperado:
        ruta = os.path.join(carpeta, item)
        if not os.path.exists(ruta):
            faltantes.append(item)

    if faltantes:
        print(c("⚠ Elementos faltantes:", Color.AMARILLO))
        for f in faltantes:
            print(" -", f)
    else:
        print(c("✔ Estructura correcta", Color.VERDE))

    print()


# ============================================================
# DETECTOR DE ERRORES COMUNES
# ============================================================

def detectar_errores(carpeta=CARPETA_PROYECTO):
    print(c("\n=== DETECTOR DE ERRORES ===\n", Color.NEGRITA))

    errores = []

    for root, dirs, files in os.walk(carpeta):
        for archivo in files:
            ruta = os.path.join(root, archivo)

            if archivo.endswith(".html"):
                with open(ruta, "r", encoding="utf-8") as f:
                    contenido = f.read().lower()

                if "<div><div>" in contenido:
                    errores.append(f"{ruta}: divs anidados incorrectamente")
                if "<img" in contenido and "alt=" not in contenido:
                    errores.append(f"{ruta}: imagen sin alt")
                if contenido.count("<html") > 1:
                    errores.append(f"{ruta}: múltiples etiquetas <html>")

    if errores:
        print(c("⚠ Errores detectados:", Color.ROJO))
        for e in errores:
            print(" -", e)
    else:
        print(c("✔ No se detectaron errores comunes", Color.VERDE))

    print()
