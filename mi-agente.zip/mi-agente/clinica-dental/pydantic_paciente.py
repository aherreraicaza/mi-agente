```python
from pydantic import BaseModel

class Paciente(BaseModel):
    id: int
    nombre: str
    apellido: str
    fecha_nacimiento: str
```