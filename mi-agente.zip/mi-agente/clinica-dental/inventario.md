# Inventario de equipo y herramientas de la clínica dental
## Equipo
* Silla dental
* Iluminación dental
* Escáner dental
* Impresora 3D

## Herramientas
* Instrumentos quirúrgicos
* Material de higiene
* Medicamentos