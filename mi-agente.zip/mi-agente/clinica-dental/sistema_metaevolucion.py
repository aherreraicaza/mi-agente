text
class sistema_metaevolucion:
  def __init__(self):
    self.estado = "Activo"