<?php
// Conectarse a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clinica_dental";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Comprobar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener datos del formulario
$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$telefono = $_POST['telefono'];
$fecha = date("Y-m-d");

// Ingresar datos en la base de datos
$sql = "INSERT INTO citas (nombre, correo, telefono, fecha) VALUES ('$nombre', '$correo', '$telefono', '$fecha')";
$conn->query($sql);

// Cerrar la conexión
$conn->close();

// Redireccionar a la página de confirmación
header("Location: confirmacion.php");
exit();
?>