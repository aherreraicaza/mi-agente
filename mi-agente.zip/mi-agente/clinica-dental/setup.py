```python
from setuptools import setup, find_packages

setup(
    name="clinica_dental",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "fastapi==0.98.0",
        "sqlalchemy==1.4.28",
        "pydantic==1.9.1",
    ],
)
```
============================================================
3) ACCIONES
============================================================
ACTIONS:
- ACTION: INSTALAR_DEPENDENCIAS(name="clinica_dental")
- ACTION: CREAR_ESTRUCTURA_BD(name="clinica_dental")
- ACTION: CONFIGURAR_FASTAPI(name="clinica_dental")
- ACTION: RUN_SERVER(name="clinica_dental")