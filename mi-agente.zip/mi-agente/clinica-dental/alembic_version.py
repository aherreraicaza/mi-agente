revision = 0.1
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    # aplicación de cambios
    op.create_table(
        'pacientes',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('nombre', sa.String(length=255), nullable=True),
        sa.Column('apellido', sa.String(length=255), nullable=True),
        sa.Column('email', sa.String(length=255), nullable=True),
        sa.Column('telefono', sa.String(length=255), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )

def downgrade():
    # descenso de cambios
    op.drop_table('pacientes')

archivos: migration.py
from alembic import op
from sqlalchemy import MetaData
from sqlalchemy.sql import text

target_metadata = MetaData()

def upgrade():
    op.create_table(
        'pacientes',
        op.Column('id', sa.Integer(), nullable=False),
        op.Column('nombre', sa.String(length=255), nullable=True),
        op.Column('apellido', sa.String(length=255), nullable=True),
        op.Column('email', sa.String(length=255),nullable=True),
        op.Column('telefono', sa.String(length=255), nullable=True))

def downgrade():
    op.drop_table('pacientes')

============================================================
3) ACCIONES
============================================================
ACTIONS:
- ACTION: CREAR_TABLA(nombre_tabla)
- ACTION: INSERTAR_REGISTRO(id_paciente=1, nombre_paciente='Juan')
- ACTION: USAR_IA_CODIGO(descripcion de acción)
- ACTION: USAR_IA_TEXTO(descripcion de acción)
- ACTION: USAR_IA_IMAGEN(descripcion de acción)