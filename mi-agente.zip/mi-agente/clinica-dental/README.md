text
Esto es una presentación sobre cómo funciona Internet.
En ella, exploraremos los conceptos fundamentales de la red más grande del mundo.