text
class Paciente:
  def __init__(self, nombre, edad, contacto):
    self.nombre = nombre
    self.edad = edad
    self.contacto = contacto

  def __str__(self):
    return f"Paciente: {self.nombre}, Edad: {self.edad}, Contacto: {self.contacto}"