#!/bin/bash

# Actualizar los paquetes
sudo apt update && sudo apt upgrade -y

# Instalar Ansible
sudo apt install ansible -y

# Ejecutar playbook
ansible-playbook -i inventario playbook_ansible.yml