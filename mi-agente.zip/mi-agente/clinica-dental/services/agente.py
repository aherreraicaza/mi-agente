text
class Agente:
    def __init__(self, proyecto: Proyecto):
        self.proyecto = proyecto

    def generar_proyecto(self):
        # Generar el proyecto
        pass