text
class Proyecto:
    def __init__(self, nombre: str):
        self.nombre = nombre