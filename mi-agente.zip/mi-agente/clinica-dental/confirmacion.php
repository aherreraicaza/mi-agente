<?php
// Obtener la fecha de la cita
$fecha = date("Y-m-d");

// Comprobar si hay citas registradas para ese día
$conn = new mysqli("localhost", "root", "", "clinica_dental");
$stmt = $conn->prepare("SELECT * FROM citas WHERE fecha = ?");
$stmt->bind_param("s", $fecha);
$stmt->execute();
$result = $stmt->get_result();

// Comprobar si hay resultados
if ($result->num_rows > 0) {
    echo "¡Tienes citas registradas para el día $fecha!";
} else {
    echo "No tienes citas registradas para el día $fecha.";
}

// Cerrar la conexión
$conn->close();
?>

============================================================
3) ACCIONES
============================================================
ACTIONS:
- ACTION: USAR_IA_CODIGO(generar_codigo_reserva())
- ACTION: USAR_IA_TEXTO(hacer_reserva(nombre, email, telefono))
- ACTION: USAR_IA_IMAGEN(enviar_imagen(archivo))
- ACTION: GENERAR_PROYECTO(clinica_dental)

Nota: Las acciones deben ser implementadas por la IA correspondiente para completar la tarea.