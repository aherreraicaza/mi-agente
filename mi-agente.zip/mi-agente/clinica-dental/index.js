```javascript
// Función para capturar el formulario de reservas
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('#reservas form');
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        const nombre = form.querySelector('#nombre').value;
        const fecha = form.querySelector('#fecha').value;
        const hora = form.querySelector('#hora').value;
        // Aquí se podría agregar lógica para guardar la reserva en la base de datos o enviar un correo electrónico
        console.log(`Reserva realizada para ${nombre} el ${fecha} a las ${hora}`);
    });
});
```

**3) ACCIONES**
============================================================
ACTIONS:
- ACTION: GENERAR_PROYECTO(clínica dental)
- ACTION: USAR_IA_CODIGO(diseñar la estructura de la web)
- ACTION: USAR_IA_TEXTO(redactar el contenido de la web)
- ACTION: USAR_IA_IMAGEN(cargar las imágenes de la web)