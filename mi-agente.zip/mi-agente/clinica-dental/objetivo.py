```python
# Importa la biblioteca de IA Evolucionista
from evolucionista import Evolucionista

# Crea una instancia de Evolucionista
evolucionista = Evolucionista()

#Define el objetivo principal de la clínica dental
objetivo_principal = "Maximizar la satisfacción de los pacientes"

# Define los subobjetivos
subobjetivos = [
    "Aumentar la frecuencia de citas programadas",
    "Mejorar la calificación del servicio en Google My Business",
    "Disminuir el tiempo promedio de atención en los turnos"
]

# Almacena los resultados de la evolución en un archivo texto
def almacenar_resultado(resultado):
    with open("evolucion_{}_{}.txt".format(evolucionista.iteraciones, evolucionista.escalas), "a") as