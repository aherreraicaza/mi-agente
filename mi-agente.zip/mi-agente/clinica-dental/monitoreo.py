```
import time
import datetime
import logging

# Configuración de logging
logging.basicConfig(filename='monitoreo.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def iniciar_monitoreo():
    logging.info('Monitoreo iniciado')
    while True:
        # Realiza las acciones de monitoreo aqui
        # Por ejemplo, verificar la disponibilidad de los sensores
        logging.info('Verificando disponibilidad de sensores')
        time.sleep(1)

def reiniciar_sistema():
    logging.info('Reiniciando sistema')
    # Realiza las acciones de reinicio aqui
    # Por ejemplo, enviar un correo a los administradores
    logging.info('Correo enviado a administradores')
```