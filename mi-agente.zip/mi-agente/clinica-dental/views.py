```python
from django.shortcuts import render
from django.http import HttpResponse
from .models import ClinicaDental, Persona, Atencion

def lista_clinicas_dentales(request):
    clinicas_dentales = ClinicaDental.objects.all()
    return render(request, 'lista_clinicas_dentales.html', {'clinicas_dentales': clinicas_dentales})

def lista_atenciones(request, clínica_dental_id):
    atenciones = Atencion.objects.filter(clínica_dental_id=clínica_dental_id)
    return render(request, 'lista_atenciones.html', {'atenciones': atenciones})
```