text
class PacienteService:
  def get_pacientes(self):
    return Paciente.objects.all()

  def crear_paciente(self, nombre, apellidos, fecha_de_nacimiento):
    paciente = Paciente.objects.create(nombre=nombre, apellidos=apellidos, fecha_de_nacimiento=fecha_de_nacimiento)
    return paciente