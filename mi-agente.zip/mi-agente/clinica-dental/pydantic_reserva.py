```python
from pydantic import BaseModel

class Reserva(BaseModel):
    id: int
    paciente_id: int
    fecha: str
    hora: str
```