text
def leer_configuracion() -> Dict:
    # Leer la configuración del archivo config.json
    pass