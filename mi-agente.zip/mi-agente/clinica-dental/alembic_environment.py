from alembic import op
from sqlalchemy import MetaData

target_metadata = MetaData()

def run_migrations_online(
        conn,
        target_metadata=None,
        config=None,
        compare_to_head=False,
        sqlalchemy_url=None,
        branch_label=None,
        revision_id=None):

    conn = op.get_bind(conn, target_metadata)
    with conn.begin() as conn:
        with conn.begin() as transaction:
            transaction.execute(target_metadata.tables[-1].create)