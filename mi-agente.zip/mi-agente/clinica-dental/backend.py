import datetime

def generar_reserva(nombre, apellido, fecha, hora):
  reserva = {
    "nombre": nombre,
    "apellido": apellido,
    "fecha": fecha,
    "hora": hora
  }
  return reserva

def usar_IA_TEXTO(reserva):
  texto = f"Reserva realizada para {reserva['nombre']} {reserva['apellido']} en {reserva['fecha']} a las {reserva['hora']}."
  return texto

def usar_IA_CODIGO(reserva):
  codigo = f"{reserva['nombre']}{reserva['apellido']}{reserva['fecha']}{reserva['hora']}"
  return codigo

def usar_IA_IMAGEN(reserva):
  imagen = f"reserva_{reserva['nombre']}{reserva['apellido']}_{reserva['fecha']}.jpg"
  return imagen

def ACTION_GENERAR_RESERVA(nombre_proyecto):
  fecha_actual = datetime.datetime.now().strftime("%Y-%m-%d")
  hora_actual = datetime.datetime.now().strftime("%H:%M")
  reserva = generar_reserva("nombre", "apellido", fecha_actual, hora_actual)
  texto = usar_IA_TEXTO(reserva)
  codigo = usar_IA_CODIGO(reserva)
  imagen = usar_IA_IMAGEN(reserva)
  return texto, codigo, imagen

============================================================
3) ACCIONES
============================================================
ACTIONS:
- ACTION: GENERAR_RESERVA(clinica_dental)
- ACTION: USAR_IA_CODIGO(determina código de reserva)
- ACTION: USAR_IA_TEXTO(describe la reserva)
- ACTION: USAR_IA_IMAGEN(genera una imagen de la reserva)