```python
from django.urls import path
from . import views

urlpatterns = [
    path('clinicas-dentales/', views.lista_clinicas_dentales, name='lista_clinicas_dentales'),
    path('clinicas-dentales/<int:clínica_dental_id>/atenciones/', views.lista_atenciones, name='lista_atenciones'),
]
```