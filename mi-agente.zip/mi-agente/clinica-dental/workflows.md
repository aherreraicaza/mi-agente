# Sistema de Automatizaciones para la Clínica Dental

## Descripción

El sistema de automatizaciones para la clínica dental está diseñado para automatizar tareas rutinarias y mejorar la eficiencia del personal.

## Workflows

### Workflow 1: Solicitud de cita

* Cuando un paciente realiza una solicitud de cita:
 + Enviar un correo electrónico al personal de la clínica para notificar la solicitud.
 + Agregar la solicitud a la agenda de cita.
* Cuando el personal de la clínica confirma la cita:
 + Enviar un correo electrónico al paciente para confirmar la cita.
 + Agregar la cita a la agenda de cita.

### Workflow 2: Confirmación de pago

* Cuando un paciente realiza un pago:
 + Enviar un correo electrónico al personal de la clínica para notificar el pago.
 + Actualizar el registro del paciente para reflejar el pago realizado.

### Workflow 3: Notificación de recordatorios

* Cuando una cita esté próxima a expirar:
 + Enviar un correo electrónico al paciente para recordar la cita.
 + Enviar un correo electrónico al personal de la clínica para notificar la cita próxima.

**