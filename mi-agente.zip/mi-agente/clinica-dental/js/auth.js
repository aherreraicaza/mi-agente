const loginForm = document.getElementById('login-form');
const registroForm = document.getElementById('registro-form');

loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
    })
        .then((response) => response.json())
        .then((data) => {
            if (data.token) {
                localStorage.setItem('token', data.token);
                window.location.href = 'index.html';
            } else {
                alert('Credenciales incorrectas');
            }
        })
        .catch((error) => console.error(error));
});

registroForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const nombre = document.getElementById('nombre').value;
    fetch('/api/registro', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, nombre }),
    })
        .then((response) => response.json())
        .then((data) => {
            if (data.token) {
                localStorage.setItem('token', data.token);
                window.location.href = 'index.html';
            } else {
                alert('Error al registrar usuario');
            }
        })
        .catch((error) => console.error(error));
});

============================================================
3) ACCIONES
============================================================
ACTIONS:
- ACTION: GENERAR_PROYECTO(clinica_dental)
- ACTION: USAR_IA_CODIGO(autenticar_usuario)
- ACTION: USAR_IA_TEXTO(generar_token)
- ACTION: USAR_IA_IMAGEN(verificar_email)

Notas:

- La autenticación real se gestionará a través de un backend con Node.js y Express.js.
- El token de autenticación se almacenará en localStorage del navegador.
- La autenticación de usuarios se realizará mediante fetch a la API.
- El registro de usuarios se realizará mediante fetch a la API.