javascript
// Variables
const titulo = document.querySelector("h1");
const imagen = document.querySelector("img");

// Eventos
titulo.addEventListener("mouseover", () => {
    titulo.style.color = "#008000";
});

titulo.addEventListener("mouseout", () => {
    titulo.style.color = "#00698f";
});

imagen.addEventListener("click", () => {
    location.href = "https://example.com";
});

ARCHIVO: imagen.jpg