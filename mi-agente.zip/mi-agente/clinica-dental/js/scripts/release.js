// Script para crear un release en GitHub
const axios = require('axios');

module.exports = async function createRelease() {
  // Obtenemos el token de acceso al repositorio
  const token = process.env.GITHUB_TOKEN;
  const repoOwner = 'your-username';
  const repoName = 'your-repo-name';

  // Creamos la URL para crear un release
  const createReleaseUrl = `https://api.github.com/repos/${repoOwner}/${repoName}/releases`;

  // Creamos el cuerpo del release
  const releaseBody = {
    tag_name: 'v1.0.0',
    target_commitish: 'main',
    name: 'Release 1.0.0',
    body: 'Release 1.0.0',
    draft: false,
    prerelease: false,
  };

  // Creamos el release en GitHub
  const response = await axios.post(createReleaseUrl, releaseBody, {
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
  });

  console.log(response.data);
};

============================================================
3) ACCIONES
============================================================
ACTIONS:
- ACTION: CREAR_SISTEMA_VERSIONADO(Git y GitHub)
- ACTION: CONFIGURAR_FLUJO_DE_TRABAJO_GITHUB_ACTIONS
- ACTION: CREAR_RELEASE_EN_GITHUB(descripción del release)