const express = require('express');
const app = express();
const port = 3000;

app.set('view engine', 'html');

app.get('/', (req, res) => {
    res.render('index', {
        title: 'Clínica Dental',
        servicios: [
            'Tratamientos de conveniencia',
            'Tratamientos cosmeticos',
        ],
        testimonios: [
            {
                texto: 'He tenido una experiencia excelente en esta clínica.',
                autor: '— Juan Pérez'
            }
        ]
    });
});

app.listen(port, () => {
    console.log(`Servidor en el puerto ${port}`);
});