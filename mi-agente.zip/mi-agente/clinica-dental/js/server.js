const express = require('express');
const app = express();
const path = require('path');

app.set('view engine', 'html');

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

const port = 3000;
app.listen(port, () => {
    console.log(`Servidor en el puerto ${port}`);
});

============================================================
3) ACCIONES
============================================================
Aquí defino qué debe hacer el backend:

ACTIONS:
- ACTION: GENERAR_PROYECTO(clinica_dental)
- ACTION: USAR_IA_TEXTO(diseñar la estructura del proyecto)
- ACTION: USAR_IA_IMAGEN(probar el diseño)
- ACTION: USAR_IA_CODIGO(app.js con funcionalidades básicas)