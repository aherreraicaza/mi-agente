```javascript
// Obtener elementos HTML
const reservaForm = document.getElementById("reserva-form");

// Agregar evento al formulario
reservaForm.addEventListener("submit", (e) => {
    e.preventDefault();
    // Obtener datos del formulario
    const nombre = document.getElementById("nombre").value;
    const correo = document.getElementById("correo").value;
    const fecha = document.getElementById("fecha").value;
    const hora = document.getElementById("hora").value;

    // Enviar formulario al servidor
    fetch("/reserva", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nombre, correo, fecha, hora }),
    })
        .then((response) => response.json())
        .then((data) => console.log(data))
        .catch((error) => console.error(error));
});
```