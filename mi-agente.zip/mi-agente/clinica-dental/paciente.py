text
class Paciente(models.Model):
  nombre = models.CharField(max_length=50)
  apellidos = models.CharField(max_length=50)
  fecha_de_nacimiento = models.DateField()