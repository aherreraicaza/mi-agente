```javascript
// Función para abrir la página de inicio
function abrirInicio() {
    window.location.href = "index.html";
}

// Función para abrir la página de servicios
function abrirServicios() {
    window.location.href = "servicios.html";
}

// Función para abrir la página de contacto
function abrirContacto() {
    window.location.href = "contacto.html";
}
```