text
def evaluacion():
  return "Proyecto evaluado con éxito"

CARPETA: models