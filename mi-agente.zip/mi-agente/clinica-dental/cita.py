text
class Cita(models.Model):
  fecha = models.DateField()
  hora = models.TimeField()
  paciente = models.ForeignKey(Paciente, on_delete=models.CASCADE)

CARPETA: services