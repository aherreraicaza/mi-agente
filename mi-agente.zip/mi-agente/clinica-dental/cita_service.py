text
class CitaService:
  def get_citas(self):
    return Cita.objects.all()

  def crear_cita(self, fecha, hora, paciente_id):
    cita = Cita.objects.create(fecha=fecha, hora=hora, paciente_id=paciente_id)
    return cita

CARPETA: utils