text
class Servicio:
  def __init__(self, nombre, descripcion):
    self.nombre = nombre
    self.descripcion = descripcion

  def __str__(self):
    return f"Servicio: {self.nombre}, Descripción: {self.descripcion}"