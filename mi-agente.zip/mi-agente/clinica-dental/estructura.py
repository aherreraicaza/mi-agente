text
class estructura:
  def __init__(self):
    self.titulo = "Clínica Dental"
    self.descripcion = "Proveedora de servicios de odontología y bienestar"