```
# Configuración del monitoreo
MONITOREO_TIEMPO = 1  # Tiempo en segundos para el monitoreo

# Configuración para el reinicio automático
REINICIO_TIEMPO = 24 * 60 * 60  # Tiempo en segundos para el reinicio
```