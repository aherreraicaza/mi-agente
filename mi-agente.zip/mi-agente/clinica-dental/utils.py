text
def leer_archivo(archivo):
  try:
    with open(archivo, 'r') as file:
      contenido = file.read()
      return contenido
  except Exception as e:
    return str(e)