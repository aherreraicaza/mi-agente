```python
import tkinter as tk
from tkinter import messagebox

class ClínicaDental:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Clínica Dental")
        self.root.geometry("800x600")

        # Creamos los frames
        self.frame_principal = tk.Frame(self.root)
        self.frame_principal.pack(fill="both", expand=True)

        # Creamos la barra de menú
        self.barra_menor = tk.Menu(self.root)
        self.barra_menor.add_command(label="Agregar Paciente", command=self.agregar_paciente)
        self.barra_menor.add_command(label="Listar Pacientes", command=self.listar_pacientes)
        selfbarra_menor.add_command(label="Salir", command=self.salir)
        self.root.config(menu=self.barra_menor)

        # Creamos el frame de los botones
        self.frame_botones = tk.Frame(self.root)
        self.frame_botones.pack(fill="x")

        self.boton_agregar_paciente = tk.Button(self.frame_botones, text="Agregar Paciente", command=self.agregar_paciente)
        self.boton_agregar_paciente.pack(side="left")

        self.boton_listar_pacientes = tk.Button(self.frame_botones, text="Listar Pacientes", command=self.listar_pacientes)
        self.boton_listar_pacientes.pack(side="left")

        self.boton_salir = tk.Button(self.frame_botones, text="Salir", command=self.salir)
        self.boton_salir.pack(side="right")

        self.root.mainloop()

    def agregar_paciente(self):
        ventana_agregar_paciente = tk.Toplevel(self.root)
        ventana_agregar_paciente.title("Agregar Paciente")

        # Creamos los labels y entrys
        label_nombre = tk.Label(ventana_agregar_paciente, text="Nombre:")
        label_nombre.pack()
        entry_nombre = tk.Entry(ventana_agregar_paciente)
        entry_nombre.pack()

        label_apellido = tk.Label(ventana_agregar_paciente, text="Apellido:")
        label_apellido.pack()
        entry_apellido = tk.Entry(ventana_agregar_paciente)
        entry_apellido.pack()

        label_fecha_nacimiento = tk.Label(ventana_agregar_paciente, text="Fecha de Nacimiento:")
        label_fecha_nacimiento.pack()
        entry_fecha_nacimiento = tk.Entry(ventana_agregar_paciente)
        entry_fecha_nacimiento.pack()

        # Creamos el botón de guardar
        boton_guardar = tk.Button(ventana_agregar_paciente, text="Guardar", command=lambda: self.guardar_paciente(entry_nombre.get(), entry_apellido.get(), entry_fecha_nacimiento.get()))
        boton_guardar.pack()

    def listar_pacientes(self):
        # Mostramos los pacientes en una lista
        lista_pacientes = tk.Listbox(self.root)
        lista_pacientes.pack(fill="both", expand=True)

        # Simulamos que hay pacientes en la base de datos
        pacientes = ["Juan Pérez", "Lucía García", "Juan Manuel Pérez"]
        for paciente in pacientes:
            lista_pacientes.insert(tk.END, paciente)

    def guardar_paciente(self, nombre, apellido, fecha_nacimiento):
        # Simulamos que guardamos el paciente en la base de datos
        messagebox.showinfo("Paciente Guardado", f"Paciente {nombre} {apellido} guardado con éxito.")

    def salir(self):
        # Cerramos la ventana
        self.root.destroy()

# Creamos la instancia de la clase
clínica_dental = ClínicaDental()
```