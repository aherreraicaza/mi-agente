# Datos de la Clínica

- **Día de apertura**: Miércoles
- **Horario de atención**: 8:00 AM - 6:00 PM
- **Número de visitantes**: 150 al día
- **Promedio de facturación por paciente**: 500 USD

DADO: sistema_clinica.json
{
    "nombre_clinica": "Clínica Dental",
    "direccion": "Calle 123",
    "hora_apertura": "8:00 AM",
    "hora_cierre": "6:00 PM",
    "numero_visitantes": 150,
    "promedio_facturacion": 500
}

============================================================
3) ACCIONES
============================================================
ACTIONS:
- ACTION: USAR_IA_DATOS(describir la petición de datos a la IA)
- ACTION: USAR_IA_CODIGO(escribir el código utilizado en la función obtenedora)
- ACTION: USAR_IA_TEXTO(realizar el análisis del texto y obtener recomendaciones)
- ACTION: GENERAR_REPORTE(nombrar el reporte a generar y su descripción)

En el caso de esta clínica dental, la acción a realizar sería:

- ACTION: USAR_IA_DATOS("Análizar los datos de la clínica para mejorar resultados")
- ACTION: USAR_IA_CODIGO("La función obtenerResultado utiliza un algoritmo de aprendizaje automático para analizar datos y emitir recomendaciones")
- ACTION: USAR_IA_TEXTO("Revisar la descripción del sistema de auto-mejora controlada y obtener recomendaciones para la clínica")
- ACTION: GENERAR_REPORTE("Informe de Mejoramiento de la Clínica Dental")