def run(carpeta="proyectos_web"):
    contenido = "<h2>Política de Privacidad</h2><p>Contenido generado automáticamente.</p>"
    with open(f"{carpeta}/privacy.html", "w", encoding="utf-8") as f:
        f.write(contenido)
    return "✔ Página de privacidad generada."
