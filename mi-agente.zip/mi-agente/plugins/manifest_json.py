import json, os

def run(carpeta="proyectos_web"):
    manifest = {
        "name": "Mi App Web",
        "short_name": "AppWeb",
        "start_url": "/",
        "display": "standalone",
        "background_color": "#ffffff",
        "theme_color": "#000000"
    }
    with open(os.path.join(carpeta, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
    return "✔ manifest.json generado."
