def run(carpeta="proyectos_web"):
    sw = """
self.addEventListener('install', e => {
  console.log('Service Worker instalado');
});
"""
    with open(f"{carpeta}/service-worker.js", "w", encoding="utf-8") as f:
        f.write(sw)
    return "✔ service-worker.js generado."
