def run(carpeta="proyectos_web"):
    contenido = "Contact: admin@example.com\n"
    with open(f"{carpeta}/security.txt", "w", encoding="utf-8") as f:
        f.write(contenido)
    return "✔ security.txt generado."
