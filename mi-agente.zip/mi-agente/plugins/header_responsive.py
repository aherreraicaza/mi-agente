import os

def run(carpeta="proyectos_web"):
    header = """
<header style="padding:20px;background:#111;color:white;">
  <h2>Mi Sitio Web</h2>
</header>
"""
    for root, dirs, files in os.walk(carpeta):
        for f in files:
            if f.endswith(".html"):
                ruta = os.path.join(root, f)
                with open(ruta, "r", encoding="utf-8") as file:
                    html = file.read()

                html = html.replace("<body>", "<body>\n" + header)

                with open(ruta, "w", encoding="utf-8") as file:
                    file.write(html)

    return "✔ Header responsive añadido."
