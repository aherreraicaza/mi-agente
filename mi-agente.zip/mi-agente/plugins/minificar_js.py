import os, re

def run(carpeta="proyectos_web"):
    count = 0
    for root, dirs, files in os.walk(carpeta):
        for f in files:
            if f.endswith(".js"):
                ruta = os.path.join(root, f)
                with open(ruta, "r", encoding="utf-8") as file:
                    js = file.read()

                js = re.sub(r"\s+", " ", js)
                with open(ruta, "w", encoding="utf-8") as file:
                    file.write(js)
                count += 1

    return f"✔ JS minificado ({count} archivos)."
