import requests
import os

def run(prompt=None):
    """
    Plugin GPT‑4o
    Uso:
        plugin gpt4o "tu texto aquí"
    """

    if prompt is None:
        return "Debes escribir: plugin gpt4o \"tu texto\""

    # Clave API desde variable de entorno
    api_key = os.getenv("OPENAI_API_KEY")

    if not api_key:
        return "❌ Falta la clave OPENAI_API_KEY en variables de entorno."

    url = "https://api.openai.com/v1/chat/completions"

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }

    data = {
        "model": "gpt-4o-mini",
        "messages": [
            {"role": "system", "content": "Eres un asistente experto y creativo."},
            {"role": "user", "content": prompt}
        ]
    }

    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        result = response.json()
        return result["choices"][0]["message"]["content"]

    except Exception as e:
        return f"❌ Error al llamar a GPT‑4o: {e}"
