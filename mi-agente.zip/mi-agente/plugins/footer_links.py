import os

def run(carpeta="proyectos_web"):
    links = """
<div style="text-align:center;">
  <a href='/privacy.html'>Privacidad</a> |
  <a href='/terms.html'>Términos</a>
</div>
"""
    for root, dirs, files in os.walk(carpeta):
        for f in files:
            if f.endswith(".html"):
                ruta = os.path.join(root, f)
                with open(ruta, "a", encoding="utf-8") as file:
                    file.write(links)

    return "✔ Enlaces añadidos al footer."
