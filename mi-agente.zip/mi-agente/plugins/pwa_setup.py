import os

def run(carpeta="proyectos_web"):
    for root, dirs, files in os.walk(carpeta):
        for f in files:
            if f.endswith(".html"):
                ruta = os.path.join(root, f)
                with open(ruta, "r", encoding="utf-8") as file:
                    html = file.read()

                if "</head>" in html:
                    html = html.replace(
                        "</head>",
                        '  <link rel="manifest" href="/manifest.json">\n</head>'
                    )

                if "</body>" in html:
                    html = html.replace(
                        "</body>",
                        '  <script>navigator.serviceWorker.register("/service-worker.js")</script>\n</body>'
                    )

                with open(ruta, "w", encoding="utf-8") as file:
                    file.write(html)

    return "✔ Proyecto convertido en PWA."
