def run(carpeta="proyectos_web"):
    contenido = "Created by an AI agent.\n"
    with open(f"{carpeta}/humans.txt", "w", encoding="utf-8") as f:
        f.write(contenido)
    return "✔ humans.txt generado."
