def run(carpeta="proyectos_web"):
    contenido = """
<h2>Blog</h2>
<article><h3>Primer post</h3><p>Contenido generado automáticamente.</p></article>
"""
    with open(f"{carpeta}/blog.html", "w", encoding="utf-8") as f:
        f.write(contenido)

    return "✔ Blog básico creado."
