import os, re

def run(carpeta="proyectos_web"):
    errores = []
    for root, dirs, files in os.walk(carpeta):
        for f in files:
            if f.endswith(".html"):
                ruta = os.path.join(root, f)
                with open(ruta, "r", encoding="utf-8") as file:
                    html = file.read()

                links = re.findall(r'href="([^"]+)"', html)
                for l in links:
                    if l.startswith("http"):
                        continue
                    if not os.path.exists(os.path.join(carpeta, l)):
                        errores.append(f"❌ Enlace roto: {l} en {ruta}")

    if errores:
        return "\n".join(errores)
    return "✔ No se encontraron enlaces rotos."
