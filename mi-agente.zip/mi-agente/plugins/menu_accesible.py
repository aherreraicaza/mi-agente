import os

def run(carpeta="proyectos_web"):
    menu = """
<nav role="navigation">
  <ul>
    <li><a href="/">Inicio</a></li>
    <li><a href="/blog.html">Blog</a></li>
    <li><a href="/contacto.html">Contacto</a></li>
  </ul>
</nav>
"""
    for root, dirs, files in os.walk(carpeta):
        for f in files:
            if f.endswith(".html"):
                ruta = os.path.join(root, f)
                with open(ruta, "r", encoding="utf-8") as file:
                    html = file.read()

                html = html.replace("<body>", "<body>\n" + menu)

                with open(ruta, "w", encoding="utf-8") as file:
                    file.write(html)

    return "✔ Menú accesible añadido."
