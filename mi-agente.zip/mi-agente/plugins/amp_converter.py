import os, re

def run(carpeta="proyectos_web"):
    for root, dirs, files in os.walk(carpeta):
        for f in files:
            if f.endswith(".html"):
                ruta = os.path.join(root, f)
                with open(ruta, "r", encoding="utf-8") as file:
                    html = file.read()

                html = html.replace("<html", "<html amp")
                html = re.sub(r"<script[^>]*>", "", html)

                with open(ruta, "w", encoding="utf-8") as file:
                    file.write(html)

    return "✔ Conversión AMP aplicada."
