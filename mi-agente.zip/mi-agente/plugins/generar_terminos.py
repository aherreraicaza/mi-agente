def run(carpeta="proyectos_web"):
    contenido = "<h2>Términos y Condiciones</h2><p>Contenido generado automáticamente.</p>"
    with open(f"{carpeta}/terms.html", "w", encoding="utf-8") as f:
        f.write(contenido)
    return "✔ Página de términos generada."
