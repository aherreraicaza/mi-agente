def run(carpeta="proyectos_web"):
    contenido = "User-agent: *\nAllow: /\n"
    with open(f"{carpeta}/robots.txt", "w", encoding="utf-8") as f:
        f.write(contenido)
    return "✔ robots.txt generado."
