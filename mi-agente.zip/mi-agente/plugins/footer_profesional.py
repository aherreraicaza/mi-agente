import os

def run(carpeta="proyectos_web"):
    footer = """
<footer style="text-align:center;padding:20px;margin-top:40px;">
  © 2026 - Sitio generado automáticamente
</footer>
"""
    for root, dirs, files in os.walk(carpeta):
        for f in files:
            if f.endswith(".html"):
                ruta = os.path.join(root, f)
                with open(ruta, "r", encoding="utf-8") as file:
                    html = file.read()

                html = html.replace("</body>", footer + "\n</body>")

                with open(ruta, "w", encoding="utf-8") as file:
                    file.write(html)

    return "✔ Footer añadido."
