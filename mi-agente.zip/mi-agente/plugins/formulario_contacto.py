import os

def run(carpeta="proyectos_web"):
    form = """
<section>
  <h2>Contacto</h2>
  <form>
    <input type="text" placeholder="Nombre"><br><br>
    <input type="email" placeholder="Email"><br><br>
    <textarea placeholder="Mensaje"></textarea><br><br>
    <button>Enviar</button>
  </form>
</section>
"""
    for root, dirs, files in os.walk(carpeta):
        for f in files:
            if f.endswith(".html"):
                ruta = os.path.join(root, f)
                with open(ruta, "a", encoding="utf-8") as file:
                    file.write(form)

    return "✔ Formulario de contacto añadido."
