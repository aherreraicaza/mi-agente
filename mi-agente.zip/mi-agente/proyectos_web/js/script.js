text
var ideas = [
  "E-commerce de productos sostenibles",
  "Plataforma de aprendizaje en línea",
  "Aplicación de pago móvil",
  "Sitio web de noticias y notificaciones",
  "Plataforma de redes sociales para expertos"
];

for (var i = 0; i < ideas.length; i++) {
  document.write("<p>" + ideas[i] + "</p>");
}