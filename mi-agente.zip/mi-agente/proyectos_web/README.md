text
# Proyecto de ideas de negocios digitales
Este proyecto genera ideas de negocios digitales a partir de una solicitud del usuario.