# 📘 Documentación del Proyecto

Este documento describe la estructura y funcionamiento del proyecto.

## Archivo: clinica.json
Ruta: `proyectos_web\clinica.json`


## Archivo: config.json
Ruta: `proyectos_web\config.json`


## Archivo: DOCUMENTACION.md
Ruta: `proyectos_web\DOCUMENTACION.md`


## Archivo: index.html
Ruta: `proyectos_web\index.html`

- Contiene la estructura principal del sitio.

## Archivo: README.md
Ruta: `proyectos_web\README.md`


## Archivo: style.css
Ruta: `proyectos_web\css\style.css`

- Contiene los estilos visuales.

## Archivo: script.js
Ruta: `proyectos_web\js\script.js`

- Contiene la lógica e interactividad.

